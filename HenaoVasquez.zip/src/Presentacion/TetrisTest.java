package Presentacion;

import javax.swing.*;

public class TetrisTest {
    private JPanel panel1;
    private JTextArea TetrisWelcome;
    private JButton button1;
    private JButton button2;
    private JButton button3;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
